package com.icia.board.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
@Slf4j
public class Homecontroller {

    @GetMapping("/join")
    public String join(){

        return "join";
    }

    @GetMapping("/")
    public String home(){

        return "redirect:/main";
    }

    @GetMapping("/main")
    public String main(){
        return"main";
    }
    @GetMapping("/login")
    public  String login(){
        return "login";
    }

}
