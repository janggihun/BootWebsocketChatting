package com.icia.board.controller;


import com.icia.board.dto.Person;
import com.icia.board.repository.PersonRepository;
import com.icia.board.service.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@Controller
public class PersonController {



    @Autowired
    private PersonService personService;

    @PostMapping("/singup")
    public String singup(Person person){

       personService.insert(person);
        System.out.println("person = " + person);

        return "redirect:/login";
    }

    @PostMapping("/find")
    public  String login(Person person, Model model){
      boolean result = personService.find(person);
        if (result){

            return "redirect:/main";

        }else {
            return "redirect:/join";
        }
    }


}
