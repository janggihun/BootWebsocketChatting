package com.icia.board.repository;

import com.icia.board.dto.Person;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import javax.print.DocFlavor;

@Repository
public interface PersonRepository extends CrudRepository<Person, String> {

}
